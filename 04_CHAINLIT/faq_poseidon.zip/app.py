
import chainlit as cl
from agno.agent import Agent
from agno.models.openai import OpenAIChat
from agno.agent import Agent, AgentMemory
from chainlit import user_session
from rich.pretty import pprint
from agno.models.groq import Groq
from agno.models.openrouter import OpenRouter
from dotenv import main
from teams import *
import os
from agno.models.openai import OpenAIChat
from agno.embedder.openai import OpenAIEmbedder
from teams import knowledge_base_customer
main.load_dotenv()
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
db_url = "postgresql+psycopg://neondb_owner:npg_CzA3eXY9cwBs@ep-spring-sun-a52z84u0-pooler.us-east-2.aws.neon.tech/neondb?sslmode=require"

agent = Agent(
    model=model_openai_teams_agent,
    description="You are a customer assistant at POSÉIDON SPA.",
    role="You are a customer assistant at POSÉIDON SPA. Your role is to assist user by answering its inquiries, providing detailed information, and ensuring an excellent customer experience.",

    team=[costumer_assistant,technician_agent],
    markdown=True,
    #add_history_to_messages=True,
    #num_history_responses=5,
    #read_chat_history=True,
    #add_datetime_to_instructions=True,
   # show_tool_calls=True,
    debug_mode=True,
    retries=3,

)

@cl.set_starters
async def set_starters():
    questions = [
        "je suis a GAILLAC, et je veux acheter un spa, y a t il un de vos partenaire dans cette ville?",
        "Où se trouve la localisation du by-pass et de la vidange ?",
        "Il y a une un bruit intense et une odeur de brûlé au lancement du spa après hivernage ?",
        "A partir du mode réglage CHAUFFAGE du système balboa comment faire apparaître dans la rubrique « mode » celui prêt en repos RR?",
        "Le sens d’ouverture de la porte est-il modifiable ?",
        "Est-ce que les branchements en Plug and Play demande de réaliser un délestage sur les machines ?",
        "Y a-t-il le module wifi intégré pour le spa Orion ?",
        "Y a-t-il une distance à respecter entre la paroi du sauna et le mur ?",
        "Y a-t-il une distance à respecter entre le plafond et le toit du sauna ?",
        "Le sauna est-il livré avec le kit accessoire ? Sur le catalogue il est noté 1 thermomètre."
    ]

    return [
        cl.Starter(
            label=value,
            message=value
        ) for value in questions
    ]


@cl.on_message
async def on_message(message: cl.Message):
    mh = cl.user_session.get("message_history", [])
    msg = cl.Message("", author="AI Agent")
    final_msg_content = ""
    for rest in agent.run(message.content, stream=True):
        await msg.stream_token(rest.content, False)
    await msg.update()
    print("~"*100)

    print("~"*100)


